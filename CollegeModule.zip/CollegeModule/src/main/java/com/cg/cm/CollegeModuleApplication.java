package com.cg.cm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeModuleApplication.class, args);
	}

}
