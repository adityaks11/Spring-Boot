package com.cg.cm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
